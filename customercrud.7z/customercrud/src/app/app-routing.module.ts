import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerlistComponent } from './component/customerlist/customerlist.component';
import { AboutComponent } from './component/about/about.component';
import { ContactComponent } from './component/contact/contact.component';
import { AddcustomerComponent } from './component/addcustomer/addcustomer.component';
import { UpdatecustomerComponent } from './component/updatecustomer/updatecustomer.component';
import { AddreactiveComponent } from './addreactive/addreactive.component';


const routes: Routes = [
  {path:'',redirectTo:'listcustomer',pathMatch:'full'},
  {path:'home',redirectTo:'listcustomer',pathMatch:'full'},
  {path:'listcustomer',component:CustomerlistComponent},
  {path:'about',component:AboutComponent},
  {path:'contact',component:ContactComponent},
  {path:'add',component:AddcustomerComponent},
  {path:'listcustomer/update/:id',component:UpdatecustomerComponent},
  {path:'addreactive',component:AddreactiveComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
