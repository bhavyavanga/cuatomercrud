import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ContactComponent } from './component/contact/contact.component';
import { CustomerlistComponent } from './component/customerlist/customerlist.component';
import { AddcustomerComponent } from './component/addcustomer/addcustomer.component';
import { UpdatecustomerComponent } from './component/updatecustomer/updatecustomer.component';
import { AboutComponent } from './component/about/about.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CustomerService } from './service/customer.service';
import { AddreactiveComponent } from './addreactive/addreactive.component'
@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    ContactComponent,
    CustomerlistComponent,
    AddcustomerComponent,
    UpdatecustomerComponent,
    AddreactiveComponent,

  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule

  ],
  providers: [CustomerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
